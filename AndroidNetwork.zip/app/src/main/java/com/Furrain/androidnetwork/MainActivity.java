package com.Furrain.androidnetwork;

import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.Furrain.androidnetwork.adapters.GetResultListAdapter;
import com.Furrain.androidnetwork.domain.GetItem;
import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    GetResultListAdapter mAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        InitView();
    }

    private void InitView(){
        RecyclerView recyclerView = findViewById(R.id.result_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
            @Override
            public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
                outRect.top = 3;
                outRect.bottom = 3;
            }
        });
        mAdapter = new GetResultListAdapter();
        recyclerView.setAdapter(mAdapter);
    }

    public void LoadJson(View view){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL http = new URL("http://10.0.2.2:9102/get/text");
                    HttpURLConnection connection = (HttpURLConnection) http.openConnection();

                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setRequestProperty("accept", "*/*");
                    connection.setRequestProperty("Accept-Language", "zh-CN,zh,q=0.9");
                    connection.connect();
                    int responseCode = connection.getResponseCode();
                    if(responseCode == 200){
                        Map<String,List<String>> headerFields = connection.getHeaderFields();
                        for(Map.Entry<String,List<String>> enty : headerFields.entrySet()){
                            Log.i("MainWindow", enty.getKey() + ":" + enty.getValue());
                        }
                        InputStream inputStream = connection.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

                        String s = null;
                        String temp = null;
                        s = reader.readLine();

                        Gson gson = new Gson();
                        GetItem getItem = gson.fromJson(s, GetItem.class);
                        UpdateUI(getItem);
                }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    //个人知道的方法 1.在子线程中使用runOnUiThread
    // 2使用handler，完成手发送一个handler信号提醒方法执行
    private void UpdateUI(final GetItem getItem)
    {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mAdapter.setData(getItem);
            }
        });
    }

//    void LoadBigPic()
//    {
//        //假如ic_launch_round是一个很大的图片，此时会崩溃OOM，此时要是用采样率
//        //采样率
//        //但是采样率不应该写死，应该根据控件的大小动态计算
//        BitmapFactory.Options options = new BitmapFactory.Options();
//        //c此时拿到图片，但是不加载
//        options.inJustDecodeBounds = true;
//        BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher_round, options);
//        int outHeight = options.outHeight;
//        int outWidth = options.outWidth;
//
//        //拿到控件的尺寸
//        ImageView img = xxxxx;
//        int measureHeight = img.getMeasuredHeight();
//        int measureWidth = img.getMeasuredWidth();
//        // 图片宽度/ 控件宽度
//        // 图片高度/ 控件高度
//        // q取两者最小值
//        // 当图片小雨控件 就默认为1
//        options.inSampleSize = 1;
//        if(outHeight > measureHeight || outWidth > measureWidth){
//            int subHeight = outHeight / measureHeight;
//            int subWidth = outWidth / measureWidth;
//            options.inSampleSize = subHeight > subWidth ? subWidth : subHeight;
//        }
//        options.inJustDecodeBounds = false;
//
//        Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher_round, options);
//
//        img.setImageBitmap(bitmap);
//    }


}
