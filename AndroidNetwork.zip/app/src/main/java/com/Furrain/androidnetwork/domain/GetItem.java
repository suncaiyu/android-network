package com.Furrain.androidnetwork.domain;

import java.util.List;

public class GetItem {

    /**
     * success : true
     * code : 10000
     * message : 获取成功
     * data : [{"id":"1208343581971013632","title":"Android加载大图片，解决OOM问题","viewCount":173,"commentCount":96,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/0.png"},{"id":"1208343581971013633","title":"Volley/Xutils对大图片处理算法源码分析","viewCount":219,"commentCount":45,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/1.png"},{"id":"1208343581971013634","title":"Android开发网络安全配置","viewCount":123,"commentCount":55,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/2.png"},{"id":"1208343581971013635","title":"Android开发网络编程，请求图片","viewCount":125,"commentCount":80,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/11.png"},{"id":"1208343581971013636","title":"Intent页面跳转工具类分享","viewCount":328,"commentCount":57,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/10.png"},{"id":"1208343581971013637","title":"阳光沙滩商城的API文档","viewCount":256,"commentCount":83,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/1.png"},{"id":"1208343581971013638","title":"Android课程视频打包下载","viewCount":133,"commentCount":98,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/12.png"},{"id":"1208343581971013639","title":"非常轻量级的gif录制软件","viewCount":292,"commentCount":100,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/6.png"},{"id":"1208343581971013640","title":"Fiddler抓包工具，墙裂推荐，功能很强大很全的一个工具","viewCount":128,"commentCount":58,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/12.png"},{"id":"1208343581971013641","title":"AndroidStudio奇淫技巧-代码管理","viewCount":71,"commentCount":10,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/9.png"},{"id":"1208343581971013642","title":"OC和Swift混编","viewCount":33,"commentCount":56,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/8.png"},{"id":"1208343581971013643","title":"最新的Android studio是不是没有Android Device Monitor","viewCount":71,"commentCount":79,"publishTime":"2019-12-21T11:08:54.537+0000","userName":"程序员拉大锯","cover":"/imgs/7.png"}]
     */

    private boolean success;
    private int code;
    private String message;
    private List<DataBean> data;

    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<DataBean> getData() {
        return data;
    }

    public void setData(List<DataBean> data) {
        this.data = data;
    }

    public static class DataBean {
        /**
         * id : 1208343581971013632
         * title : Android加载大图片，解决OOM问题
         * viewCount : 173
         * commentCount : 96
         * publishTime : 2019-12-21T11:08:54.537+0000
         * userName : 程序员拉大锯
         * cover : /imgs/0.png
         */

        private String id;
        private String title;
        private int viewCount;
        private int commentCount;
        private String publishTime;
        private String userName;
        private String cover;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public int getViewCount() {
            return viewCount;
        }

        public void setViewCount(int viewCount) {
            this.viewCount = viewCount;
        }

        public int getCommentCount() {
            return commentCount;
        }

        public void setCommentCount(int commentCount) {
            this.commentCount = commentCount;
        }

        public String getPublishTime() {
            return publishTime;
        }

        public void setPublishTime(String publishTime) {
            this.publishTime = publishTime;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getCover() {
            return cover;
        }

        public void setCover(String cover) {
            this.cover = cover;
        }
    }
}
