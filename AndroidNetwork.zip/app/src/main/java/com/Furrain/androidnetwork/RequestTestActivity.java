package com.Furrain.androidnetwork;

import android.annotation.TargetApi;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.Furrain.androidnetwork.domain.CommentItem;
import com.google.gson.Gson;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class RequestTestActivity extends AppCompatActivity {
    final static String HttpBase = "http://10.0.2.2:9102";
    final static String Tag = "PostTestActivity";

    // Storage Permissions
    private static final int REQUEST_EXTERNAL_STORAGE = 1;

    @TargetApi(Build.VERSION_CODES.FROYO)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_test);
        File PICTURES = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    public void GetWithParam(View view){
        Map<String, String> params = new HashMap<>();
        params.put("keyword","这是我的关键字");
        params.put("page","12");
        params.put("order","0");
        startRequest(params, "GET", "/get/param");
    }
    public void PostWithParam(View view){
        Map<String, String> params = new HashMap<>();
        params.put("string","这是我的关键字");
        startRequest(params, "POST", "/post/string");
    }

    public void SimplePost(View view){
        new Thread(new Runnable() {
            @Override
            public void run() {
                OutputStream outputStream = null;
                BufferedReader br = null;
                URL url = null;
                try {
                    String Boundary = "--------------------------875613256897946";
                    url = new URL(HttpBase + "/file/upload");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setConnectTimeout(10000);
                    httpURLConnection.setRequestProperty("User-Agent","Android/" + Build.VERSION.SDK_INT);
                    httpURLConnection.setRequestProperty("Accept","*/*");
                    httpURLConnection.setRequestProperty("Cache-Control","no-cache");
                    httpURLConnection.setRequestProperty("Content-Type","multipart/form-data; boundary=" + Boundary);
                    httpURLConnection.setRequestProperty("Connection", "keep-alive");
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.setDoOutput(true);
                    String fileKey = "file";
                    File file = new File("/storage/emulated/0/Download/6.png");
                    String fileName = file.getName();
                    httpURLConnection.connect();
                    outputStream = httpURLConnection.getOutputStream();
                    UploadFile(file,fileKey,fileName,"image/jpeg",Boundary,true,outputStream);
                    outputStream.flush();
                    int responseCode = httpURLConnection.getResponseCode();
                    Log.d(Tag,"responseCode--->" + responseCode);
                    int num = responseCode + 1;
                    if(responseCode == HttpURLConnection.HTTP_OK){
                        InputStream inputStream = httpURLConnection.getInputStream();
                        br = new BufferedReader(new InputStreamReader(inputStream));
                        String json = br.readLine();
                        Log.d(Tag,"json--=-=-=->" + json);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    if (br != null) {
                        try {
                            br.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        }).start();

    }
    public void MorePost(View view){
        new Thread(new Runnable() {
            URL url = null;
            OutputStream outputStream = null;
            BufferedReader br = null;
            @Override
            public void run() {
                String Boundary = "--------------------------875613256897946";
                try {
                    url = new URL(HttpBase + "/files/upload");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setRequestMethod("POST");
                    httpURLConnection.setConnectTimeout(10000);
                    httpURLConnection.setRequestProperty("User-Agent","Android/" + Build.VERSION.SDK_INT);
                    httpURLConnection.setRequestProperty("Accept","*/*");
                    httpURLConnection.setRequestProperty("Cache-Control","no-cache");
                    httpURLConnection.setRequestProperty("Content-Type","multipart/form-data; boundary=" + Boundary);
                    httpURLConnection.setRequestProperty("Connection", "keep-alive");
                    httpURLConnection.setDoInput(true);
                    httpURLConnection.setDoOutput(true);
                    File file1 = new File("/storage/emulated/0/Download/6.png");
                    File file2 = new File("/storage/emulated/0/Download/O1CN01D0Woff1vxxvum8ONn_!!0-saturn_solar.jpg_210x210.jpg");
                    File file3 = new File("/storage/emulated/0/Download/wechat-subscription.jpg");
                    String fileName1 = file1.getName();
                    String fileName2 = file2.getName();
                    String fileName3 = file3.getName();


                    httpURLConnection.connect();
                    outputStream = httpURLConnection.getOutputStream();
                    UploadFile(file1,"files",fileName1,"image/jpeg",Boundary,false,outputStream);
                    UploadFile(file2,"files",fileName2,"image/jpeg",Boundary,false,outputStream);
                    UploadFile(file3,"files",fileName3,"image/jpeg",Boundary,true,outputStream);
                    outputStream.flush();


                    int responseCode = httpURLConnection.getResponseCode();
                    Log.d(Tag,"responseCode--->" + responseCode);
                    int num = responseCode + 1;
                    if(responseCode == HttpURLConnection.HTTP_OK){
                        InputStream inputStream = httpURLConnection.getInputStream();
                        br = new BufferedReader(new InputStreamReader(inputStream));
                        String json = br.readLine();
                        Log.d(Tag,"json--=-=-=->" + json);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }finally{
                    if (br != null) {
                        try {
                            br.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }

            }
        }).start();
    }

    private void UploadFile(File file, String filekey, String fileName, String fileType, String BOUNDARY, boolean isLast , OutputStream outputStream) throws IOException {
        StringBuilder header = new StringBuilder();
        header.append("--");
        header.append(BOUNDARY);
        header.append("\r\n");
        header.append("Content-Disposition: form-data; name=\"" + filekey +"\"; filename=\"" + fileName + "\"");
        header.append("\r\n");
        header.append("Content-Type: "+ fileType);
        header.append("\r\n");
        header.append("\r\n");
        byte[] bytesheader = header.toString().getBytes("UTF-8");
        outputStream.write(bytesheader);
        //文件内容
        FileInputStream fis = new FileInputStream(file);
        BufferedInputStream bis = new BufferedInputStream(fis);
        byte[] buf = new byte[1024];
        int len;
        while ((len = bis.read(buf,0,buf.length)) != -1){
            outputStream.write(buf,0,len);
        }
        //weibu xinxi
        StringBuilder footerSbInfo = new StringBuilder();
        footerSbInfo.append("\r\n");
        footerSbInfo.append("--");
        footerSbInfo.append(BOUNDARY);
        if(isLast) {
            footerSbInfo.append("--");
            footerSbInfo.append("\r\n");
        }
        footerSbInfo.append("\r\n");
        outputStream.write(footerSbInfo.toString().getBytes("UTF-8"));
    }


    public void DownloadFile(View view){
        new Thread(new Runnable() {
            URL url = null;
            @TargetApi(Build.VERSION_CODES.FROYO)
            @Override
            public void run() {
                FileOutputStream fileOutputStream = null;
                InputStream inputStream = null;
                try {
                    url = new URL(HttpBase + "/download/9");
                    HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
                    httpURLConnection.setConnectTimeout(10000);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.connect();
                    httpURLConnection.getInputStream();
                    int responseCode = httpURLConnection.getResponseCode();
                    Log.d(Tag,"responseCode--->" + responseCode);
                    if (responseCode == HttpURLConnection.HTTP_OK) {
                        Map<String, List<String>> header = httpURLConnection.getHeaderFields();
                        for(Map.Entry<String, List<String>> entry : header.entrySet()){
                            Log.d(Tag,  entry.getKey() + " ========" + entry.getValue());
                        }
                        List<String> strings = header.get("Content-disposition");
                        String filename = null;
                        for(String string : strings){
                            int i = string.indexOf("filename=");
                            filename = string.substring(i + "filename=".length());
                            Log.d(Tag,"filename----->" + filename);
                        }
                        File filesDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
                        if (!filesDir.exists()) {
                            filesDir.mkdirs();
                        }
                        File file = new File(filesDir +"/"+ filename);
                        if (!file.exists()) {
                            file.createNewFile();
                        }
                        fileOutputStream = new FileOutputStream(file);
                        inputStream = httpURLConnection.getInputStream();
                        byte[] bytes = new byte[1024];
                        int len;
                        while ((len = inputStream.read(bytes, 0, bytes.length)) != -1){
                            fileOutputStream.write(bytes,0,len);
                        }
                        fileOutputStream.flush();
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (fileOutputStream != null) {
                        try {
                            fileOutputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }
    private void startRequest(final Map<String, String> params, final String method, final String api) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                URL url = null;
                BufferedReader bufferedReader = null;
                try {
                    //zu zhuang can shu
                    if(params != null){
                        StringBuilder sb = new StringBuilder("?");
                        Iterator<Map.Entry<String, String>> iterator =  params.entrySet().iterator();
                        while(iterator.hasNext()){
                            Map.Entry<String, String> next = iterator.next();
                            sb.append(next.getKey());
                            sb.append("=");
                            sb.append(next.getValue());
                            if(iterator.hasNext()){
                                sb.append("&");
                            }
                        }
                        Log.d(Tag,"sb.result --->" + sb.toString());
                        String params = sb.toString();
                        if(params != null && params.length() > 0){
                            url = new URL(HttpBase + api + params);
                        }else{
                            url = new URL(HttpBase + api);
                        }
                        Log.d(Tag,url.toString());

                    }
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod(method);
                    connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8\n");
                    connection.setRequestProperty("Accept", "application/json,text/plain,*/*");
                    connection.connect();
                    int responseCode = connection.getResponseCode();
                    if(responseCode == HttpURLConnection.HTTP_OK){
                        InputStream inputStream = connection.getInputStream();
                        bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                        String json = bufferedReader.readLine();
                        Log.d(Tag,"json-->" + json);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    if (bufferedReader != null) {
                        try {
                            bufferedReader.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }


    //post带信息的请求 如上传评论
    public void PostText(View view)
    {
        new Thread(new Runnable() {
            @Override
            public void run() {
                InputStream inputStream = null;
                OutputStream outputStream = null;
                try {
                    URL url = new URL("http://10.0.2.2:9102/post/comment");
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(10000);
                    connection.setRequestProperty("Content-Type", "application/json;charset=UTF-8\n");
                    connection.setRequestProperty("Accept", "application/json,text/plain,*/*");
                    CommentItem commentItem = new CommentItem("4567813", "我是内容.....hoho");
                    Gson gson = new Gson();
                    String jsonStr = gson.toJson(commentItem);
                    byte[] bytes = jsonStr.getBytes("UTF-8");
                    connection.setRequestProperty("Content-Length", bytes.length + "");
                    Log.d(Tag, "bytes.length() --->" + bytes.length);
                    connection.connect();

                    outputStream = connection.getOutputStream();
                    outputStream.write(bytes);
                    outputStream.flush();

                    int responseCode = connection.getResponseCode();
                    if(responseCode == 200){
                        inputStream = connection.getInputStream();
                        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                        Log.d(Tag,bufferedReader.readLine());
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }).start();
    }
}
