package com.Furrain.androidnetwork.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.Furrain.androidnetwork.R;
import com.Furrain.androidnetwork.domain.GetItem;
import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class GetResultListAdapter extends RecyclerView.Adapter<GetResultListAdapter.Holder> {
    private List<GetItem.DataBean> mData = new ArrayList<>();
    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_get_text,parent,false);
        return new Holder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        View itemView = holder.itemView;
        TextView titleTv = itemView.findViewById(R.id.item_title);
        GetItem.DataBean dataBean = mData.get(position);
        titleTv.setText(dataBean.getTitle());
        TextView authorTv = itemView.findViewById(R.id.author);
        authorTv.setText(dataBean.getUserName());
        TextView numTv = itemView.findViewById(R.id.view_num);
        numTv.setText(dataBean.getViewCount() + "");
        ImageView imgView = itemView.findViewById(R.id.showImage);
        String picPath = "http://10.0.2.2:9102" + dataBean.getCover();
        Glide.with(itemView.getContext()).load(picPath).into(imgView);
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public void setData(GetItem getItem) {
        mData.clear();
        mData.addAll(getItem.getData());
        notifyDataSetChanged();
    }

    public class Holder extends RecyclerView.ViewHolder {
        public Holder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
