package com.Furrain.androidnetwork;

import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.Furrain.androidnetwork.domain.CommentItem;
import com.google.gson.Gson;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class OkhttpActivity extends AppCompatActivity {

    private static final String URLBASR = "http://10.0.2.2:9102";
    private static final String Tag = "OkhttpActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_okhttp);
    }

    public void GetRequest(View view){
        // 要有一个客户端，类似我们要有一个浏览器
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000, TimeUnit.MILLISECONDS)
                .build();

        // 创建一个链接
        Request request = new Request.Builder()
                .get()
                .url(URLBASR + "/get/text")
                .build();


        // 用client创建request请求任务
        Call task = okHttpClient.newCall(request);

        //异步请求
        task.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(Tag,"onFailure ---->"+ e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                int code = response.code();
                Log.d(Tag,"requestCode---->"+code);
                ResponseBody body = response.body();
                String string = body.string();
                Log.d(Tag,"body---->"+string);
            }
        });
    }


    public void PostComment(View view){

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000,TimeUnit.MILLISECONDS)
                .build();

        //请求体
        CommentItem commentItem = new CommentItem("4897123","wuwuuwuwuwu");
        Gson gson = new Gson();
        String toJson = gson.toJson(commentItem);
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody requestBody = RequestBody.create(toJson,mediaType);

        Request request = new Request.Builder()
                .post(requestBody)
                .url(URLBASR + "/post/comment")
                .build();

        Call call = okHttpClient.newCall(request);

        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(Tag,"onFailure ---->"+ e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                int code = response.code();
                Log.d(Tag,"requestCode---->"+code);
                ResponseBody body = response.body();
                String string = body.string();
                Log.d(Tag,"body---->"+string);
            }
        });
    }

    public void UploadSignalFile(View view) throws IOException {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000,TimeUnit.MILLISECONDS)
                .build();

        File file = new File("/storage/emulated/0/Download/wechat-subscription.jpg");
        MediaType mediaType =MediaType.parse("application/pdf");
        RequestBody filebody = RequestBody.create(file,mediaType);
        RequestBody requestBody = new MultipartBody.Builder()
                .addFormDataPart("file",file.getName(),filebody)
                .build();

        Request request = new Request.Builder()
                .url(URLBASR + "/file/upload")
                .post(requestBody)
                .build();

        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(Tag,"onFailure ---->"+ e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                int code = response.code();
                Log.d(Tag,"requestCode---->"+code);
                ResponseBody body = response.body();
                String string = body.string();
                Log.d(Tag,"body---->"+string);
            }
        });
    }

    public void UploadFiles(View view){
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000,TimeUnit.MILLISECONDS)
                .build();

        File file = new File("/storage/emulated/0/Download/wechat-subscription.jpg");
        File file2 = new File("/storage/emulated/0/Download/O1CN01D0Woff1vxxvum8ONn_!!0-saturn_solar.jpg_210x210.jpg");
        File file3 = new File("/storage/emulated/0/Download/6.png");
        MediaType mediaType = MediaType.parse("image/jpeg");
        RequestBody fileBody1 = RequestBody.create(file,mediaType);
        RequestBody fileBody2 = RequestBody.create(file2,mediaType);
        RequestBody fileBody3 = RequestBody.create(file3,mediaType);
        RequestBody requestBody = new MultipartBody.Builder()
                .addFormDataPart("files",file.getName(),fileBody1)
                .addFormDataPart("files",file2.getName(),fileBody2)
                .addFormDataPart("files",file3.getName(),fileBody3)
                .build();

        Request request = new Request.Builder()
                .post(requestBody)
                .url(URLBASR +"/files/upload")
                .build();

        Call task = okHttpClient.newCall(request);
        task.enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                Log.d(Tag,"onFailure ---->"+ e.toString());
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                int code = response.code();
                Log.d(Tag,"requestCode---->"+code);
                ResponseBody body = response.body();
                String string = body.string();
                Log.d(Tag,"body---->"+string);
            }
        });
    }

    public void DownloadFiles(View view){
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(10000,TimeUnit.MILLISECONDS)
                .build();



        Request request = new Request.Builder()
                .get()
                .url(URLBASR + "/download/7")
                .build();

        final Call task = okHttpClient.newCall(request);
        new Thread(new Runnable() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void run() {
                try {
                    Response excute = task.execute();
                    Headers headers = excute.headers();
                    String filename = null;
                    String name = headers.get("Content-disposition");
                    filename = name.replace("attachment; filename=","");

                    File loadFile = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + filename);
                    Log.d(Tag,"file-->"+loadFile);
                    if(!loadFile.getParentFile().exists()){
                        loadFile.getParentFile().mkdirs();
                    }
                    if (!loadFile.exists()) {
                        loadFile.createNewFile();
                    }
                    FileOutputStream fos = new FileOutputStream(loadFile);
                    if(excute.body()!=null){
                        InputStream inputStream = excute.body().byteStream();
                        byte[] buff = new byte[1024];
                        int len;
                        while((len = inputStream.read(buff,0,buff.length)) != -1){
                            fos.write(buff,0,len);
                        }
                        fos.flush();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();

//        task.enqueue(new Callback() {
//            @Override
//            public void onFailure(@NotNull Call call, @NotNull IOException e) {
//                Log.d(Tag,"onFailure ---->"+ e.toString());
//            }
//
//            @Override
//            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
//                int code = response.code();
//                Log.d(Tag,"requestCode---->"+code);
//                Headers headers = response.headers();
//                String filename = new String();
//                String name = headers.get("Content-disposition");
//                filename = name.replace("attachment; filename=","");
//                ResponseBody body = response.body();
//                //注意不要随便调用body.tostring，否则汇报异常。
////                String string = body.string();
//                File loadFile = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES) + "/" + filename);
//                if(!loadFile.getParentFile().exists()){
//                    loadFile.getParentFile().mkdirs();
//                }
//                if (!loadFile.exists()) {
//                    loadFile.createNewFile();
//                }
//                InputStream inputStream = body.byteStream();
//                FileOutputStream fileOutputStream = new FileOutputStream(loadFile);
//                byte[] buff = new byte[1024];
//                int len;
//                while((len = inputStream.read(buff,0,buff.length)) != -1){
//                    fileOutputStream.write(buff,0,len);
//                }
//                fileOutputStream.flush();
//            }
//        });
    }
}
